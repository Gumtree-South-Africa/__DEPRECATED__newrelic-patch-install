**string_decoder.js** (`require('string_decoder')`) from Node.js core

Copyright Joyent, Inc. and other Node contributors. See LICENCE file for details.

Version numbers match the versions found in Node core, e.g. 0.10.24 matches Node 0.10.24, likewise 0.11.10 matches Node 0.11.10. **Prefer the stable version over the unstable.**

The *build/* directory contains a build script that will scrape the source from the [joyent/node](https://github.com/joyent/node) repo given a specific Node version.